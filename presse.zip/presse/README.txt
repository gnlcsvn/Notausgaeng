Dieser Ordner enthält Promo-Material der Band Notausgäng. Dieses darf ausdrücklich nur zum Zweck der Pressearbeit und/oder Werbung im Zusammenhang mit der Band verwendet werden. Die Bildrechte der Bandfotos liegen bei Steven Kowalzik (für das Strandbild) und bei Steven Kowalzik + Felix Wagner (für das Bandfoto), welche bei Verwendung der Bilder nach Möglichkeit namentlich aufgeführt werden sollen (z.B. bei der Verwendung von Bildern in Presseartikeln). 
Die hier bereitgestellten Texte und Informationen sind Eigentum der Band und dürfen im Ganzen aber auch in Teilen (z.B. zurecht geschnitten Bilder) frei für den jeweiligen Zweck verwendet werden. 

Bilder liegen als .jpg Dateien vor.
Texte je nach bedarf als PDF, Word oder .txt Datei.

Liebe Grüße
Notausgäng